package service21Package;

/**
 * 
 * @author Era2
 * Interface for a simple Web Service
 */
public interface Service21 {
	public String capitalFromIP(String ip);
}
